#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_Add_clicked()
{
    QListWidgetItem* item = new QListWidgetItem(ui->txtTask->text(),ui->listWidget); //add in text box
    ui->listWidget->addItem(item);
    item->setFlags(item->flags()| Qt::ItemIsEditable); //create new edit item or edit the item which is added
    ui->txtTask->clear(); //clear text box
    ui->txtTask->setFocus();
}


void MainWindow::on_Remove_clicked()
{
    QListWidgetItem* item = ui->listWidget->takeItem(ui->listWidget->currentRow());
    delete item;

}


void MainWindow::on_DeleteAll_clicked()
{
    ui->listWidget->clear();

}

